@extends('site.layouts.default')

{{-- Content --}}
@section('content')
@foreach ($posts as $post)
<article class="blog-post">
	<h2 class="blog-post-title"><a href="{{{ $post->url() }}}">{{ String::title($post->title) }}</a></h2>
	<div class="blog-post-meta">
		<span class="glyphicon glyphicon-user"></span> by <span class="muted">{{{ $post->author->username }}}</span>
		| <span class="glyphicon glyphicon-calendar"></span>{{{ $post->date() }}}
		| <span class="glyphicon glyphicon-comment"></span><a href="{{{ $post->url() }}}#comments">{{ $post->comments()->count() }} {{ \Illuminate\Support\Pluralizer::plural('Comment', $post->comments()->count()) }}</a>
	</div>
	<p>{{ String::tidy(Str::limit($post->content, 200)) }}<a href="{{{ $post->url() }}}" class="btn btn-link">Read more</a></p>
</article>

<hr>
@endforeach

{{ $posts->links() }}

@stop


{{-- Sidebar --}}
@section('sidebar')
	@include('site.layouts.sidebar')
@stop