<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>
	@section('title')
	Administration
	@show
	</title>

	<meta name="keywords" content="your, awesome, keywords, here" />
	<meta name="author" content="Jon Doe" />
	<meta name="description" content="Lorem ipsum dolor sit amet, nihil fabulas et sea, nam posse menandri scripserit no, mei." />

	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- CSS -->
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/wysihtml5/prettify.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/wysihtml5/bootstrap-wysihtml5.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/datatables-bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/colorbox.css')}}">
	
	<style>
	/* Sticky footer styles
	-------------------------------------------------- */
	html {
	  position: relative;
	  min-height: 100%;
	}
	body {
	  /* Margin bottom by footer height */
	  margin-bottom: 60px;
	}
	.footer {
	  position: absolute;
	  bottom: 0;
	  width: 100%;
	  /* Set the fixed height of the footer here */
	  height: 60px;
	  background-color: #f5f5f5;
	}
	#main .page-header {
	margin-top: 0;
	}
	</style>
	@yield('styles')

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

</head>
<body>

<div id="wrap">
	<header class="navbar navbar-default navbar-static-top" role="navigation">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="{{ URL::to('/') }}">Laravel</a>
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">
	      	<li {{ (Request::is('/') ? 'class="active"' : '') }}><a href="{{{ URL::to('') }}}">Home</a>
	      </ul>

	      <ul class="nav navbar-nav pull-right">
			@if (Auth::check())
				@if (Auth::user()->hasRole('admin'))
				<li {{ (Request::is('admin') ? 'class="active"' : '') }}><a href="{{{ URL::to('admin') }}}">Admin Panel</a></li>
				@endif
				<li {{ (Request::is('users') ? 'class="active"' : '') }}><a href="{{{ URL::to('users') }}}">Logged in as {{{ Auth::user()->username }}}</a></li>
				<li {{ (Request::is('users/login') ? 'class="active"' : '') }}><a href="{{{ URL::to('users/logout') }}}">Logout</a></li>
			@else
				<li {{ (Request::is('user/login')) ? 'class="active"' : '' }}><a href="{{{ URL::to('users/login') }}}">Login</a></li>
				<li {{ (Request::is('user/register')) ? 'class="active"' : '' }}><a href="{{{ URL::to('users/create') }}}">Register</a></li>
			@endif
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</header>

	<div id="main" class="container-fluid">
		@include('notifications')
		<!-- EO notifications -->

		<div class="row">
			<div class="col-md-2 blog-sidebar">
			@include('admin.layouts.sidebar')
			</div>
			<!-- EO sidebar -->

			<div class="col-md-10 blog-main">
			@yield('content')
			</div>
			<!-- EO blog-main -->
		</div>
	</div>
	<!-- EO main container -->

	<div id="push"></div>
	<!-- EO #push - for sticky footer -->
</div>
<!-- EO #wrap -->

<footer class="footer">
	<div class="container-fluid">
		@section('footer')
		<p class="text-muted">Laravel 4 CMS</p>
		@show
	</div>
</footer>

<!-- Javascripts -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="{{asset('js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/js/wysihtml5/wysihtml5-0.3.0.js')}}"></script>
<script src="{{asset('assets/js/wysihtml5/bootstrap-wysihtml5.js')}}"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
<script src="{{asset('assets/js/datatables-bootstrap.js')}}"></script>
<script src="{{asset('assets/js/datatables.fnReloadAjax.js')}}"></script>
<script src="{{asset('assets/js/jquery.colorbox.js')}}"></script>
<script src="{{asset('assets/js/prettify.js')}}"></script>

<script type="text/javascript">
	$('.wysihtml5').wysihtml5();
    $(prettyPrint);
</script>

@yield('scripts')
</body>
</html>