<?php namespace Cms\Models;

use Zizaco\Entrust\EntrustRole;

class Role extends EntrustRole {
	
}