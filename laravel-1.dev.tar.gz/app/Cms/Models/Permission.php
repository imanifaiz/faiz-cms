<?php namespace Cms\Models;

use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission {
	
}